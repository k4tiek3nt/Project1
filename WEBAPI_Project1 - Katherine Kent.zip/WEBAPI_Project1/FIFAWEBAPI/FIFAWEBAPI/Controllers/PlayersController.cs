﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FIFAWEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
        
    public class PlayersController : ControllerBase
    {
        //Common object to call the methods
        Players pObj = new Players();

        #region HttpGet (Select) GetPlayerByName
        [HttpGet]
        [Route("playersList/player/{playerName}")]
        public IActionResult GetPlayerByName(string playerName)
        {
            try
            {
                bool checkPlayer = pObj.CheckPlayerExist(playerName);
                if (checkPlayer)
                {
                   return Ok(pObj.GetPlayerByName(playerName));
                }
                else
                {
                    throw new Exception("Player Not Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region HttpGet (Select) GetPlayerById 
        [HttpGet]
        [Route("playersList/player/byId/{playerId}")]
        public IActionResult GetPlayerById(int playerId)
        {
            try
            {
                bool checkPId = pObj.CheckPlayerIdExist(playerId);
                if (checkPId)
                {
                      return Ok(pObj.GetPlayerById(playerId));               
                }
                else
                {
                    throw new Exception("Player Not Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region HttpGet (Select) GetPlayerByPosition
        [HttpGet]
        [Route("playersList/position/{playerPosition}")]
        public IActionResult GetPlayerByPosition(string playerPosition)
        {
            try
            {
                bool checkPlayPos = pObj.CheckPositionExist(playerPosition);
                if (checkPlayPos)
                {
                    return Ok(pObj.GetPlayerByPosition(playerPosition));
                }
                else
                {
                    throw new Exception("Player Position Not Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region HttpPost (Insert) AddNewPlayer
        [HttpPost]
        [Route("playersList/add")]
        public IActionResult AddNewPlayer(Players newPlayer)
        {
            try
            {
                bool checkPlayer = pObj.CheckPlayerExist(newPlayer.playerName);
                if (!checkPlayer)
                {
                    return Ok(pObj.AddNewPlayer(newPlayer));
                }
                else
                {
                    throw new Exception("Player Already Exists, Player Not Added");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region HttpPut (Update) TradePlayer
        [HttpPut]
        [Route("playersList/trade/{playerName}/{playerTeamId}")]
        public IActionResult TradePlayer(string playerName, int playerTeamId)
        {
            try
            {
                bool checkPlayer = pObj.CheckPlayerExist(playerName);
                bool checkPtId = pObj.CheckPlayerTidExist(playerTeamId);

                if (checkPlayer)
                {
                    if (checkPtId)
                    {
                      return Ok(pObj.TradePlayer(playerName, playerTeamId));
                    }
                    else
                    {
                        throw new Exception("Player Team ID Not Found");
                    }
                }
                else
                {
                    throw new Exception("Player Not Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region HttpPut (Update) UpdatePlayerPosition
        [HttpPut]
        [Route("playersList/edit/{playerName}/{playerPosition}")]
        public IActionResult UpdatePlayerPosition(string playerName, string playerPosition)
        {
            try
            {
                bool checkPlayer = pObj.CheckPlayerExist(playerName);
                bool checkPlayPos = pObj.CheckPositionExist(playerPosition);

                if (checkPlayer)
                {
                    if (checkPlayPos)
                    {
                            return Ok(pObj.UpdatePlayerPosition(playerName, playerPosition));
                    }
                    else
                    {
                        throw new Exception("Player Position Not Found");
                    }
                }
                else
                {
                    throw new Exception("Player Not Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region HttpPut (Update) UpdatePlayerImage
        [HttpPut]
        [Route("playersList/edit/Image/{playerId}/{playerImage}")]
        public IActionResult UpdatePlayerImage(int playerId, string playerImage)
        {
            try
            {
                bool checkPId = pObj.CheckPlayerIdExist(playerId);
                bool checkUrl = pObj.CheckPlayerUrlExist(playerImage);

                if (checkPId)
                {
                    if (!checkUrl)
                    {
                       return Ok(pObj.UpdatePlayerImage(playerId, playerImage));
                    }
                    else
                    {
                        throw new Exception("Player Image Already Exists");
                    }
                }
                else
                {
                    throw new Exception("Player Not Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region HttpDelete (Delete) DeletePlayer - byName
        [HttpDelete]
        [Route("playersList/delete/{playerName}")]
        public IActionResult DeletePlayer(string playerName)
        {
            try
            {
                bool checkPlayer = pObj.CheckPlayerExist(playerName);
                if (checkPlayer)
                {
                   return Ok(pObj.DeletePlayer(playerName));
                }
                else
                {
                    throw new Exception("Player Not Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region HttpDelete (Delete) DeletePlayerById
        [HttpDelete]
        [Route("playersList/delete/byId/{playerId}")]
        public IActionResult DeletePlayerById(int playerId)
        {
            try
            {
                bool checkPId = pObj.CheckPlayerIdExist(playerId);

                if (checkPId)
                {
                   return Ok(pObj.DeletePlayerById(playerId));
                }
                else
                {
                   throw new Exception("Player Not Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
