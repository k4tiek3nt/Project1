﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FIFAWEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
       
    public class TeamsController : ControllerBase
    {
        //Common object to call the methods
        Teams tObj = new Teams();

        #region HttpGet (Select) ShowAllTeams
        [HttpGet]
        [Route("teamsList")]
        public IActionResult ShowAllTeams()
        {
            return Ok(tObj.ShowAllTeams());
        }
        #endregion

        #region HttpGet (Select) GetTeamByName
        [HttpGet]
        [Route("teamsList/{teamName}")]
        public IActionResult GetTeamByName(string teamName)
        {
            try
            {
                bool checkTeam = tObj.CheckTeamExist(teamName);
                if(checkTeam)
                {
                        return Ok(tObj.GetTeamByName(teamName));
                }
                else
                {
                    throw new Exception("Team Not Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region HttpPost (Insert) AddNewTeam
        [HttpPost]
        [Route("teamsList/add")]
        public IActionResult AddNewTeam(Teams newObj)
        {
            try
            {
                bool checkTeam = tObj.CheckTeamExist(newObj.teamName);
                if (!checkTeam)
                {                
                    return Ok(tObj.AddNewTeam(newObj));                
                }
                else
                {
                    throw new Exception("Team Already Exists, Team Not Added");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

        #region HttpPut (Update) UpdateTeamDetails
        [HttpPut]
        [Route("teamsList/Change")]
        public IActionResult UpdateTeamDetails(Teams updateTeam)
        {
            bool checkTeam = tObj.CheckTeamExist(updateTeam.teamName);
            if (checkTeam)
            {
                try
                {
                    return Ok(tObj.UpdateTeamDetails(updateTeam));
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            else
            {
                throw new Exception("Team Does Not Exist, Team Not Updated");
            }
        }
        #endregion

        #region HttpDelete (Delete) DeleteTeam - byName
        [HttpDelete]
        [Route("teamsList/delete/{teamName}")]
        public IActionResult DeleteTeam(string teamName)
        {
            bool checkTeam = tObj.CheckTeamExist(teamName);

            if (checkTeam)
            {
                try
                {
                    return Ok(tObj.DeleteTeam(teamName));
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            else
            {
                throw new Exception("Player Not Found");
            }
        }
        #endregion

        #region HttpDelete (Delete) DeleteTeamById
        [HttpDelete]
        [Route("teamsList/delete/byId/{teamId}")]
        public IActionResult DeleteTeamById(int teamId)
        {
            try
            {
                bool checkTId = tObj.CheckTeamIdExist(teamId);
                if (checkTId)
                {
                        return Ok(tObj.DeleteTeamById(teamId));
                }
                else
                {
                    throw new Exception("Team Not Found");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion

    }
}
