﻿using System.Data.SqlClient;

namespace FIFAWEBAPI
{
    public class PlayersBase
    {
        #region Properties - pulling in Teams
        public int teamId { get; set; }
        public string teamName { get; set; }
        public string teamCountry { get; set; }
        public string teamCaptain { get; set; }
        public string teamCoach { get; set; }   
        public string teamFlag { get; set; }
        public string teamJersey { get; set; }
        #endregion
    }

    public class Players : PlayersBase
    {
        #region Properties - Specific for Players
        public int playerId { get; set; }
        public string playerName { get; set; }
        public string playerPosition { get; set; }
        public int playerTeamId { get; set; }
        public int playerJersey { get; set; }
        public string playerImageUrl { get; set; }
        #endregion

        #region SqlConnection
        SqlConnection con = new SqlConnection(@"server=LAPTOP-10JSFNDB\KATIEINSTANCE;database=FIFADB;integrated security=true");
        #endregion

        #region GetPlayerByName
        public Players GetPlayerByName(string playerName)
        {
            SqlCommand cmd = new SqlCommand("select Teams.teamId, Teams.teamName, Teams.teamCountry, Teams.teamCaptain, " +
                "Teams.teamCoach, Teams.teamFlag, Teams.teamJersey, Players.playerId, Players.playerName, Players.playerPosition, " +
                "Players.playerJersey, Players.playerImageUrl from Players full join Teams on Players.playerTeamId = Teams.teamId " +
                "where playerName=@pName", con);
            cmd.Parameters.AddWithValue("@pName", playerName);

            SqlDataReader rd = null;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    Players player = new Players()
                    {
                        teamId = (int)rd[0],
                        teamName = rd[1].ToString(),
                        teamCountry = rd[2].ToString(),
                        teamCaptain = rd[3].ToString(),
                        teamCoach = rd[4].ToString(),
                        teamFlag = rd[5].ToString(),
                        teamJersey = rd[6].ToString(),
                        playerId = (int)rd[7],
                        playerName = rd[8].ToString(),
                        playerPosition = rd[9].ToString(),
                        playerJersey = (int)rd[10],
                        playerImageUrl = rd[11].ToString()
                    };
                    return player;
                } 
                throw new Exception("Player Not Found");
            }
            catch (Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                rd.Close();
                con.Close();
            }            
        }
        #endregion

        #region GetPlayerById
        public Players GetPlayerById(int playerId)
        {
            SqlCommand cmd = new SqlCommand("select Teams.teamId, Teams.teamName, Teams.teamCountry, Teams.teamCaptain, Teams.teamCoach, " +
                "Teams.teamFlag, Teams.teamJersey, Players.playerId, Players.playerName, Players.playerPosition, Players.playerJersey, " +
                "Players.playerImageUrl from Players full join Teams on Players.playerTeamId = Teams.teamId where playerId=@pId", con);
            cmd.Parameters.AddWithValue("@pId", playerId);
            SqlDataReader rd = null;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    Players player = new Players()
                    {
                        teamId = (int)rd[0],
                        teamName = rd[1].ToString(),
                        teamCountry = rd[2].ToString(),
                        teamCaptain = rd[3].ToString(),
                        teamCoach = rd[4].ToString(),
                        teamFlag = rd[5].ToString(),
                        teamJersey = rd[6].ToString(),
                        playerId = (int)rd[7],
                        playerName = rd[8].ToString(),
                        playerPosition = rd[9].ToString(),
                        playerJersey = (int)rd[10],
                        playerImageUrl = rd[11].ToString()
                    };
                    return player;
                } throw new Exception("Player Not Found");
            }
            catch (Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                rd.Close();
                con.Close();
            }
        }
        #endregion

        #region CheckPlayerExist
        public bool CheckPlayerExist(string playerName)
        {
            SqlCommand cmd = new SqlCommand("select count(*) from Players where playerName = @pName", con);
            cmd.Parameters.AddWithValue("@pName", playerName);

            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }
        #endregion

        #region GetPlayerByPosition
        public List<Players> GetPlayerByPosition(string playerPosition)
        {
            SqlCommand cmd = new SqlCommand("select Teams.teamId, Teams.teamName, Teams.teamCountry, Players.playerId, " +
                "Players.playerName, Players.playerPosition, Players.playerJersey, Players.playerImageUrl from Players " +
                "full join Teams on Players.playerTeamId = Teams.teamId where playerPosition=@playPos", con);
            cmd.Parameters.AddWithValue("@playPos", playerPosition);
            
                con.Open();
                List<Players> playByPos = new List<Players>();
                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    playByPos.Add(new Players()
                    {
                        teamId = (int)rd[0],
                        teamName = rd[1].ToString(),
                        teamCountry = rd[2].ToString(),                        
                        playerId = (int)rd[3],
                        playerName = rd[4].ToString(),
                        playerPosition = rd[5].ToString(),
                        playerJersey = (int)rd[6],
                        playerImageUrl = rd[7].ToString()
                    });
                }
                rd.Close();
                con.Close();

            return playByPos;           
        }
        #endregion

        #region CheckPositionExist
        public bool CheckPositionExist(string playerPosition)
        {
            SqlCommand cmd = new SqlCommand("select count(*) from Players where playerPosition = @playPos", con);
            cmd.Parameters.AddWithValue("@playPos", playerPosition);

            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            if (count > 1)
            {
                return true;
            }
            return false;
        }
        #endregion

        #region AddNewPlayer
        public string AddNewPlayer(Players newPlayer)
        {
            SqlCommand cmd = new SqlCommand("insert into Players (playerName, playerPosition, playerTeamId, playerJersey, " +
                "playerImageUrl) values (@pName,@playPos,@pTeamId,@pJersey,@pImage)", con);
            cmd.Parameters.AddWithValue("@pName", newPlayer.playerName);
            cmd.Parameters.AddWithValue("@playPos", newPlayer.playerPosition);
            cmd.Parameters.AddWithValue("@pTeamId", newPlayer.playerTeamId);
            cmd.Parameters.AddWithValue("@pJersey", newPlayer.playerJersey);
            cmd.Parameters.AddWithValue("@pImage", newPlayer.playerImageUrl);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();
            if (recordsAffected == 1)
            {
                return "Player Created Successfully";
            }
            throw new Exception("Player Not Created");
        }
        #endregion

        #region TradePlayer
        public string TradePlayer(string playerName, int playerTeamId)
        {
            SqlCommand cmd = new SqlCommand("update Players set playerTeamId=@pTeamId where playerName = @pName", con);
            cmd.Parameters.AddWithValue("@pName", playerName);
            cmd.Parameters.AddWithValue("@pTeamId", playerTeamId);

            con.Open();
            int changeResult = cmd.ExecuteNonQuery();
            con.Close();

            if (changeResult == 1)
            {
                return "Player Updated Successfully";
            }
            throw new Exception("Invalid Player Name, not found in system");
        }
        #endregion

        #region CheckPlayerTidExist
        public bool CheckPlayerTidExist(int playerTeamId)
        {
            SqlCommand cmd = new SqlCommand("select count(*) from Teams where teamId=@pTeamId", con);
            cmd.Parameters.AddWithValue("@pTeamId", playerTeamId);

            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }
        #endregion

        #region UpdatePlayerPosition
        public string UpdatePlayerPosition(string playerName, string playerPosition)
        {
            SqlCommand cmd = new SqlCommand("update Players set playerPosition=@playPos where playerName = @pName", con);
            cmd.Parameters.AddWithValue("@pName", playerName);
            cmd.Parameters.AddWithValue("@playPos", playerPosition);


            con.Open();
            int changePlayPosResult = cmd.ExecuteNonQuery();
            con.Close();

            if (changePlayPosResult == 1)
            {
                return "Player Updated Successfully";
            }
            throw new Exception("Invalid Player Name, not found in system");
        }
        #endregion

        #region UpdatePlayerImage
        public string UpdatePlayerImage(int playerId, string playerImageUrl)
        {
            SqlCommand cmd = new SqlCommand("update Players set playerImageUrl=@pImage where playerId = @pId", con);
            cmd.Parameters.AddWithValue("@pId", playerId);
            cmd.Parameters.AddWithValue("@pImage", playerImageUrl);


            con.Open();
            int changeImageResult = cmd.ExecuteNonQuery();
            con.Close();

            if (changeImageResult == 1)
            {
                return "Player Updated Successfully";
            }
            throw new Exception("Invalid Player Id, not found in system");
        }
        #endregion

        #region CheckPlayerIdExist
        public bool CheckPlayerIdExist(int playerId)
        {
            SqlCommand cmd = new SqlCommand("select count(*) from Players where playerId=@pId", con);
            cmd.Parameters.AddWithValue("@pId", playerId);

            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }
        #endregion

        #region CheckPlayerUrlExist
        public bool CheckPlayerUrlExist(string playerImageUrl)
        {
            SqlCommand cmd = new SqlCommand("select count(*) from Players where playerImageUrl=@pImage", con);
            cmd.Parameters.AddWithValue("@pImage", playerImageUrl);

            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }
        #endregion

        #region DeletePlayer by Name
        public string DeletePlayer(string playerName)
        {
            SqlCommand cmd = new SqlCommand("delete from players where playerName = @pName", con);
            cmd.Parameters.AddWithValue("@pName", playerName);

            con.Open();
            int deleteResult = cmd.ExecuteNonQuery();
            con.Close();

            if (deleteResult == 1)
            {
                return "Player Deleted Successfully";
            }
            throw new Exception("Invalid Player Name, not found in system");

        }
        #endregion

        #region DeletePlayerById
        public string DeletePlayerById(int playerId)
        {
            SqlCommand cmd = new SqlCommand("delete from players where playerId = @pId", con);
            cmd.Parameters.AddWithValue("@pId", playerId);

            con.Open();
            int deleteResult = cmd.ExecuteNonQuery();
            con.Close();

            if (deleteResult == 1)
            {
                return "Player Deleted Successfully";
            }
            throw new Exception("Invalid Player Id, not found in system");
        }
        #endregion
    }
}
