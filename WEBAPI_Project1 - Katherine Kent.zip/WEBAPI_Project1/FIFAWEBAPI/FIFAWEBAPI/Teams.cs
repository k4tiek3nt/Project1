﻿using System.Data.SqlClient;

namespace FIFAWEBAPI
{
    public class Teams : Players
    {
        #region Properties
        public int teamId { get; set; }
        public string teamName { get; set; }
        public string teamCountry { get; set; }
        public string teamCaptain { get; set; }
        public string teamCoach { get; set; }
        public string teamCoachUrl { get; set; }
        public string teamFlag { get; set; }
        public string teamJersey { get; set; }
        public string teamImageUrl { get; set; }
        #endregion

        #region SqlConnection
        SqlConnection con = new SqlConnection(@"server=LAPTOP-10JSFNDB\KATIEINSTANCE;database=FIFADB;integrated security=true");
        #endregion

        #region ShowAllTeams
        public List<Teams> ShowAllTeams()
        {
            SqlCommand cmd = new SqlCommand("select * from Teams", con);
            con.Open();
            List<Teams> teamsList = new List<Teams>();
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                teamsList.Add(new Teams()
                {
                    teamId = (int) rd[0],
                    teamName = rd[1].ToString(),
                    teamCountry = rd[2].ToString(),
                    teamCaptain = rd[3].ToString(),
                    teamCoach = rd[4].ToString(),
                    teamCoachUrl = rd[5].ToString(),
                    teamFlag = rd[6].ToString(),
                    teamJersey = rd[7].ToString(),
                    teamImageUrl = rd[8].ToString()

                });
            }
            rd.Close();
            con.Close();

            return teamsList;
        }
        #endregion

        #region GetTeamByName
        public List<Teams> GetTeamByName(string teamName)
        {
            SqlCommand cmd = new SqlCommand("select Teams.teamId, Teams.teamName, Teams.teamCountry, Players.playerId, " +
                "Players.playerName, Players.playerPosition, Players.playerJersey, Players.playerImageUrl from Teams " +
                "full join Players on Teams.teamId = Players.playerTeamId where teamName=@tName", con);
            cmd.Parameters.AddWithValue("@tName", teamName);
            
            con.Open();
            List<Teams> TeamList = new List<Teams>();
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                TeamList.Add(new Teams()
                {
                    teamId = (int)rd[0],
                    teamName = rd[1].ToString(),
                    teamCountry = rd[2].ToString(),
                    playerId = (int)rd[3],
                    playerName = rd[4].ToString(),
                    playerPosition = rd[5].ToString(),
                    playerJersey = (int)rd[6],
                    playerImageUrl = rd[7].ToString()
                });
            }
            rd.Close();
            con.Close();

            return TeamList;         
        }
        #endregion

        #region CheckTeamExist
        public bool CheckTeamExist(string teamName) 
        {
            SqlCommand cmd = new SqlCommand("select count(*) from Teams where teamName = @tName", con);
            cmd.Parameters.AddWithValue("@tName", teamName);

            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }
        #endregion

        #region AddNewTeam
        public string AddNewTeam(Teams newTeam)
        {
            SqlCommand cmd = new SqlCommand("insert into Teams values (@tId,@tName,@ctry,@tCap,@tCoach,@tCoachUrl,@tflag,@tJersey,@tImageUrl)", con);
            cmd.Parameters.AddWithValue("@tId", newTeam.teamId);
            cmd.Parameters.AddWithValue("@tName", newTeam.teamName);
            cmd.Parameters.AddWithValue("@ctry", newTeam.teamCountry);
            cmd.Parameters.AddWithValue("@tCap", newTeam.teamCaptain);
            cmd.Parameters.AddWithValue("@tCoach", newTeam.teamCoach);
            cmd.Parameters.AddWithValue("@tCoachUrl", newTeam.teamCoachUrl);
            cmd.Parameters.AddWithValue("@tflag", newTeam.teamFlag);
            cmd.Parameters.AddWithValue("@tJersey", newTeam.teamJersey);
            cmd.Parameters.AddWithValue("@tImageUrl", newTeam.teamImageUrl);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery(); 
            con.Close();
            if (recordsAffected > 0)
            {
                return "Team Created Successfully";
            }
            throw new Exception("Team Not Created");
        }
        #endregion

        #region UpdateTeamDetails
        public string UpdateTeamDetails(Teams updateTeam)
        {
            SqlCommand cmd = new SqlCommand("update Teams set teamCaptain=@tCap, teamCoach=@tCoach, teamCoachUrl=@tCoachUrl," +
                "teamFlag=@tflag, teamJersey=@tJersey, teamImageUrl=@tImageUrl where teamName=@tName", con);
            cmd.Parameters.AddWithValue("@tName", updateTeam.teamName);
            cmd.Parameters.AddWithValue("@tCap", updateTeam.teamCaptain);
            cmd.Parameters.AddWithValue("@tCoach", updateTeam.teamCoach);
            cmd.Parameters.AddWithValue("@tCoachUrl", updateTeam.teamCoachUrl);
            cmd.Parameters.AddWithValue("@tflag", updateTeam.teamFlag);
            cmd.Parameters.AddWithValue("@tJersey", updateTeam.teamJersey);
            cmd.Parameters.AddWithValue("@tImageUrl", updateTeam.teamImageUrl);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();
            if (recordsAffected == 1)
            {
                return "Team Updated Successfully";
            }
            throw new Exception("Team Not Updated");
        }
        #endregion

        #region CheckTeamIdExist
        public bool CheckTeamIdExist(int teamId)
        {
            SqlCommand cmd = new SqlCommand("select count(*) from Teams where teamId=@tId", con);
            cmd.Parameters.AddWithValue("@tId", teamId);

            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }
        #endregion

        #region DeleteTeam by Name
        public string DeleteTeam(string teamName)
        {
            SqlCommand cmd = new SqlCommand("delete from Teams where teamName = @tName", con);
            cmd.Parameters.AddWithValue("@tName", teamName);

            con.Open();
            int deleteResult = cmd.ExecuteNonQuery();
            con.Close();

            if (deleteResult == 1)
            {
                return "Team Deleted Successfully";
            }
            throw new Exception("Invalid Team Name, not found in system");

        }
        #endregion

        #region DeleteTeamById
        public string DeleteTeamById(int teamId)
        {
            SqlCommand cmd = new SqlCommand("delete from Teams where teamId = @tId", con);
            cmd.Parameters.AddWithValue("@tId", teamId);

            con.Open();
            int deleteResult = cmd.ExecuteNonQuery();
            con.Close();

            if (deleteResult == 1)
            {
                return "Team Deleted Successfully";
            }
            throw new Exception("Invalid Team Id, not found in system");
        }
        #endregion

    }
}