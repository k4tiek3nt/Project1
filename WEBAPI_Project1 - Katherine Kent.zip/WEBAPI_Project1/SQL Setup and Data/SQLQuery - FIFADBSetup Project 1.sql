create database FIFADB
use FIFADB

--have atleast 32 teams

-- this is exactly as teams needs to be setup without all the alterations shown below.
create table Teams
(
	teamId int primary key not null,
	teamName varchar(30) unique not null,
	teamCountry varchar(20) not null,
	teamCaptain varchar(30),
	teamCoach varchar(30),
	teamCoachUrl varchar(1000),
	teamFlag varchar(1000),
	teamJersey varchar(1000),
	teamImageUrl varchar(1000)
)	

--these alterations have been reflected above
EXEC sp_rename 'Teams.country', 'teamCountry' -- teamCountry <- update from country to teamCountry
ALTER TABLE Teams ADD teamFlag varchar(1000), teamJersey varchar(1000) -- Adding teamFlag and teamJersey
ALTER TABLE Teams ADD teamImageUrl varchar(1000) -- Adding teamImageUrl
ALTER TABLE Teams Drop column teamFlag, teamJersey, teamImageUrl -- dropping empty columns so can add more before them
ALTER TABLE Teams ADD teamCaptain varchar(30), teamCoach varchar(30), teamCoachUrl varchar(1000), teamFlag varchar(1000), teamJersey varchar(1000), teamImageUrl varchar(1000) -- added in desired order all columns

--Have atleast 10 players in every team 

--this table is setup exactly as it should be after all alterations
create table Players
(
	playerId INT IDENTITY(1,1) NOT NULL,
	playerName varchar(50) UNIQUE NOT NULL,
	playerPosition varchar(20) NOT NULL,
	playerTeamId int NOT NULL,
	playerJersey int NOT NULL,
	playerImageUrl varchar(1000),

	constraint pk_playerId primary key (playerId),
	constraint fk_playerTeamId foreign key (playerTeamId) references Teams (TeamId)
)	

--these alterations have been reflected in the Players Table
ALTER TABLE Players Add playerImageUrl varchar(1000) -- adding column for player image
ALTER TABLE Players DROP constraint fk_playerTeamId -- had to drop the foreign key to add the player image

SELECT name  
FROM sys.key_constraints  
WHERE type = 'PK'

ALTER TABLE Players DROP constraint PK__Players__655433f2be61cfa9 -- this was found from the above select statement to delete a pk I didn't specificly name
ALTER TABLE Players ALTER COLUMN playerName varchar(50) not null -- started with only 30, needed to make 50
ALTER TABLE Players ALTER COLUMN playerTeamId int not null --each player must have a team, referenced by playerTeamId - setting to not null

ALTER TABLE Players ADD constraint pk_Players PRIMARY KEY(playerId); -- readding primary key
ALTER Table Players ADD constraint fk_playerTeamId foreign key (playerTeamId) references Teams (TeamId) -- readding fk

EXEC sp_rename 'Players.playerId', 'playerJersey' -- decided would be better to have primary key that is not the jersey which had to be a composite key tied to the teamId to allow uniqueness

select * from Players order by playerTeamId, playerJersey --checking data in table

--Queries for methods in Players Class --

--GetPlayerByName
select Teams.teamId, Teams.teamName, Teams.teamCountry, Teams.teamCaptain, Teams.teamCoach, Teams.teamFlag, Teams.teamJersey, 
	Players.playerId, Players.playerName, Players.playerPosition, Players.playerJersey, Players.playerImageUrl 
	from Players full join Teams on Players.playerTeamId = Teams.teamId where playerName='Saad Al Sheeb'

--CheckPlayerExist
select count(*) from Players where playerName = 'Saad Al Sheeb'

--GetPlayerById
select Teams.teamId, Teams.teamName, Teams.teamCountry, Teams.teamCaptain, Teams.teamCoach, Teams.teamFlag, Teams.teamJersey, 
	Players.playerId, Players.playerName, Players.playerPosition, Players.playerJersey, Players.playerImageUrl
	from Players full join Teams on Players.playerTeamId = Teams.teamId where playerId=2

--GetPlayerByPosition
select Teams.teamId, Teams.teamName, Teams.teamCountry, Players.playerId, Players.playerName, Players.playerPosition, 
	Players.playerJersey, Players.playerImageUrl from Players 
	full join Teams on Players.playerTeamId = Teams.teamId where playerPosition= 'GoalKeeper'

--CheckPositionExist
select count(*) from Players where playerPosition = 'GoalKeeper'

--AddNewPlayer
insert into Players (playerName, playerPosition, playerTeamId, playerJersey, playerImageUrl) values ('Saad Al Sheeb','GoalKeeper',101, 1, 'https://img.playerswiki.com//uploads/2022/05/09/saad-1652061370.jpg')

--TradePlayer
update Players set playerTeamId=107 where playerName = 'Saad Al Sheeb' -- testing
update Players set playerTeamId=101 where playerName = 'Saad Al Sheeb' --reset data

--CheckPlayerTidExist
select count(*) from Teams where teamId=107 --checking by team instead of players because there is only 1 instance of every teamid in Teams, but used what user input for playerTeamId

--UpdatePlayerPosition
update Players set playerPosition='Forward' where playerName = 'Saad Al Sheeb' -- testing
update Players set playerPosition='GoalKeeper' where playerName = 'Saad Al Sheeb' --reset data

--UpdatePlayerImage
update Players set playerImageUrl='https://img.playerswiki.com//uploads/2022/05/09/saad-1652061370.jpg' where playerId = 1

--CheckPlayerIdExist
select count(*) from Players where playerId=300

--CheckPlayerUrlExist
select count(*) from Players where playerImageUrl='https://img.playerswiki.com//uploads/2022/05/09/saad-1652061370.jpg'

--DeletePlayer
delete from players where playerName = 'Saad Al Sheeb'

--DeletePlayerById
delete from players where playerId = 1

--Queries for methods in Teams Class --

--ShowAllTeams
select * from Teams

--GetTeamByName
select Teams.teamId, Teams.teamName, Teams.teamCountry, Players.playerId, Players.playerName, Players.playerPosition, 
	Players.playerJersey, Players.playerImageUrl from Teams full join Players on Teams.teamId = Players.playerTeamId 
	where teamName='Qatar'

--CheckTeamExist
select count(*) from Teams where teamName = 'Qatar'

--AddNewTeam
insert into Teams values (101,'Qatar','Asia','Hassan Al-Haydos','Felix Sanchez','https://assets.nst.com.my/images/articles/000_1CC19K_1548088466.jpg',
	'https://cloudinary.fifa.com/api/v3/picture/flags-sq-2/QAT?tx=c_fill,g_auto,q_auto,w_768', 'https://www.subsidesports.com/us/qatar-away-jersey-2020-2021',
	'https://i0.wp.com/www.fifaworldcupnews.com/wp-content/uploads/2022/01/Qatar-2.jpg?resize=652%2C420&ssl=1')

--UpdateTeamDetails
update Teams set teamCaptain='Hassan Al-Haydos', teamCoach='Felix Sanchez', teamCoachUrl='https://assets.nst.com.my/images/articles/000_1CC19K_1548088466.jpg',
teamFlag='https://cloudinary.fifa.com/api/v3/picture/flags-sq-2/QAT?tx=c_fill,g_auto,q_auto,w_768', teamJersey='https://www.subsidesports.com/us/qatar-away-jersey-2020-2021', 
teamImageUrl='https://i0.wp.com/www.fifaworldcupnews.com/wp-content/uploads/2022/01/Qatar-2.jpg?resize=652%2C420&ssl=1' where teamName='Qatar'

--to export the data from Players to csv file
--select playerName, playerPosition, playerTeamId, playerJersey, playerImageUrl from Players order by playerId

--to export the data from Teams to csv file
--select top(40) * from Teams

--this was done to tie in the playerImageUrl into the players table 

select playerName, playerPosition, playerTeamId, playerJersey, playerImageUrl into #tempPlayerstable2 from [Players] --
TRUNCATE TABLE [Players] --dropped all data but headers

INSERT INTO [Players](playerName, playerPosition, playerTeamId, playerJersey, playerImageUrl)
select playerName, playerPosition, playerTeamId, playerJersey, playerImageUrl from #tempPlayerstable2 order by playerTeamId, playerJersey

select * from #tempPlayerstable2 
drop table #tempPlayerstable2 

--back to just 2 tables
select * from Players
select * from Teams

